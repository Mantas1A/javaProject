import java.util.ArrayList;

public class Print {
    
    public void printduom(ArrayList sarasas) {
        for (int i=0; i < sarasas.size(); i++) {
            System.out.println("i =" + i + " : " + sarasas.get(i));
        }
        System.out.println();
    }
}
